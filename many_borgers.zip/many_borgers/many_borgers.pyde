#Drew Pickering, 203237@gscs.ca, many_borgers


def setup():
    size (200, 300)

# starting global variables
x = 0
z = 0
#this is where all key defenitions are
def keyPressed():
    global x
    global z
    if key == "p":
        x = x + 1
    if key == "o":
        x = x - 1
    if key == "b":
        z = z + 1
    if key == "n":
        z = z - 1

#where all calculations and texts are made for the burgers made for amount of
#bun and patty packages
def draw():
    global x
    global z
    background(0)
    text ( x, 180, 30)
    text ( z, 170, 45)
    q = z * 12
    e = x * 8
    o = 0
    # all texts for hamburgers made
    if (e < q):
        text(e, 120, 100)
    if (q < e):
        text(q, 120, 100)
    if ( q == e):
        text(e, 120, 100)
    
    #typeing out all the wording onto the page
    text ("hamburger pattie packages", 20, 30)
    text ("hamburger buns packages", 20, 45)
    text("total hamburgers", 20, 100)
    # takes the numbers of packages (x) has and turns it into the value of amount of
    #patties within those packages
    #does the same for buns (z)
    text(x * 8 , 90, 60)
    text(z * 12, 80, 75)
